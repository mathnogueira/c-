#ifndef SINTATICO_ERRO_H
#define SINTATICO_ERRO_H

#define NO_LBRACE				1
#define NO_RBRACE				2
#define NO_LPARENTHESIS			3
#define NO_RPARENTHESIS			4
#define NO_SEMICOLON			5


#endif
