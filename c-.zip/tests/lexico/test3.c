int func(char c, int i) {
	int r = (int) c + i;
	return r;
}

float ffunc(struct t1 op, struct t2 value) {
	op = op + 2.3e+4;
	return op - value;
}

int main(int argc, char argv[]) {
	/*
         * Comentario inutil que nao diz nada.
         *
         */
        float clan, kkk;
        clan = kkk;
        return 0;
}
