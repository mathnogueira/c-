int main() {
	int i, j;
	i = 3;
	j = i + 2;
	return 0;
}
 
