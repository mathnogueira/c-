/*
Teste1
*/if(for<=3.22e+2){
	return joao;
}else while{
	return elseif[10];
}
