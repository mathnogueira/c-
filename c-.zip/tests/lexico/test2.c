/* Comentario fudendo tudo
 *
 * int i = -3;
 * $
 +
 - /*
 *  * int m = 2;
 *  */
 *
 */
int                 i = 0;
int j = 3;
struct i = 0;
